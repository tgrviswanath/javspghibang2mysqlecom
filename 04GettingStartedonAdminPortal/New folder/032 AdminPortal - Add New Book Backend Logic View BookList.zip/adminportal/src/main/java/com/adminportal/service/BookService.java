package com.adminportal.service;

import com.adminportal.domain.Book;

public interface BookService {
	
	Book save(Book book);

}
